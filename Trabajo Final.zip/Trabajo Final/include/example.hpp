#include <stdio.h>
#include <iostream>
//funcion
int suma(int a, int b,int c);
