#include <stdio.h>
#include <iostream>
#include <example.hpp>
using namespace std;


int main(){

	int var1, var2,var3=0;
	printf("Ingrese primer valor entero para sumar");
	cin>>var1;
	printf("Ingrese segundo valor entero para sumar");
	cin>>var2
	printf("La suma de los dos valores es: ");
	suma(var1,var2,var3);
	return 0;
}
