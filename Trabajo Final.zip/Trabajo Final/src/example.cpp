#include <example.hpp>
//funcion
int suma(int a, int b,int c){
c= (a+b);
printf(c);
return a+b;
}
