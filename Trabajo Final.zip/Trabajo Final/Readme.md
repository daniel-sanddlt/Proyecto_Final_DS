Programa suma

Progra con documetos principales en c++ (ello.cpp & example.cpp)
que incluye example.hpp

corra el programa e inserte los valores para devolver la suma
 
